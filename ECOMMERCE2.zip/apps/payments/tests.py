from django.test import TestCase

# Create your tests here.
from decimal import Decimal
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase

from apps.orders.models import Order, OrderStatus

from .models import Payment, PaymentStatus
from .services import verify_payment

User = get_user_model()


def _paystack_success_response(reference):
    return {"status": True, "data": {"status": "success", "reference": reference}}


def _paystack_failed_response(reference):
    return {"status": True, "data": {"status": "failed", "reference": reference}}


class PaystackVerificationTests(TestCase):
    """Spec section 47: Paystack verification, duplicate webhook handling."""

    def setUp(self):
        self.buyer = User.objects.create_user(username="paybuyer", email="paybuyer@example.com", password="pass12345")
        self.order = Order.objects.create(
            user=self.buyer, reference="ORD-PAY-0001", status=OrderStatus.PENDING,
            email="paybuyer@example.com", full_name="Pay Buyer", phone="08000000000",
            subtotal=Decimal("20000.00"), total=Decimal("20000.00"),
        )
        self.payment = Payment.objects.create(
            order=self.order, reference="PAY-TEST-0001", amount=Decimal("20000.00"), status=PaymentStatus.PENDING,
        )

    @patch("apps.payments.services.requests.get")
    def test_successful_verification_finalizes_the_order(self, mock_get):
        mock_get.return_value.json.return_value = _paystack_success_response(self.payment.reference)

        payment, success = verify_payment(self.payment.reference)

        self.assertTrue(success)
        payment.refresh_from_db()
        self.order.refresh_from_db()
        self.assertEqual(payment.status, PaymentStatus.SUCCESS)
        self.assertEqual(self.order.status, OrderStatus.PAID)
        self.assertIsNotNone(payment.paid_at)

    @patch("apps.payments.services.requests.get")
    def test_failed_verification_marks_payment_and_order_failed(self, mock_get):
        mock_get.return_value.json.return_value = _paystack_failed_response(self.payment.reference)

        payment, success = verify_payment(self.payment.reference)

        self.assertFalse(success)
        payment.refresh_from_db()
        self.order.refresh_from_db()
        self.assertEqual(payment.status, PaymentStatus.FAILED)
        self.assertEqual(self.order.status, OrderStatus.FAILED)

    @patch("apps.payments.services.requests.get")
    def test_verifying_an_already_successful_payment_never_hits_paystack_again(self, mock_get):
        """
        Duplicate webhook handling: Paystack's webhook and the user's
        browser callback can both call verify_payment for the same
        reference. The second call must be a pure no-op - no second
        network call, no double-processing.
        """
        mock_get.return_value.json.return_value = _paystack_success_response(self.payment.reference)

        verify_payment(self.payment.reference)
        self.assertEqual(mock_get.call_count, 1)

        payment, success = verify_payment(self.payment.reference)
        self.assertTrue(success)
        self.assertEqual(mock_get.call_count, 1)  # still 1 - second call short-circuited before any HTTP request

    def test_verifying_an_unknown_reference_raises(self):
        from apps.core.exceptions import ValidationFailedError
        with self.assertRaises(ValidationFailedError):
            verify_payment("PAY-DOES-NOT-EXIST")