"""
URL configuration for toptech project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

from django.conf import settings
from django.conf.urls.static import static


handler404 = "apps.views.custom_404"
urlpatterns = [
    path('admin/', admin.site.urls),
    path("accounts/", include("apps.accounts.urls")),
    path("cart/", include("apps.cart.urls")),
    path("orders/", include("apps.orders.urls")),
    path("payments/", include("apps.payments.urls")),
    path("shop/", include("apps.catalog.urls")),
    path("sellers/", include("apps.sellers.urls")),
    path("affiliates/", include("apps.affiliates.urls")),
    path("kyc/", include("apps.kyc.urls")),
    path("riders/", include("apps.riders.urls")),
    path("notifications/", include("apps.notifications.urls")),
    path("store/", include("apps.sellers.public_urls")),
    path('', include('apps.urls')),
    path('accounts/', include('allauth.urls')),
    path("logistics/", include("apps.logistics.urls")),
]

if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL,
        document_root=settings.MEDIA_ROOT
    )