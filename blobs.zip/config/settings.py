import os
from pathlib import Path

from dotenv import load_dotenv

"""
Django settings for the toptech (NICO_APP) project.

See https://docs.djangoproject.com/en/6.0/topics/settings/ for a full
list of settings and their values.
"""

BASE_DIR = Path(__file__).resolve().parent.parent

load_dotenv(BASE_DIR / ".env")


# Security
# https://docs.djangoproject.com/en/6.0/howto/deployment/checklist/

SECRET_KEY = os.environ.get("SECRET_KEY")




# Symmetric key for encrypting sensitive KYC fields (apps.core.fields.EncryptedCharField).
# Deliberately separate from SECRET_KEY - rotating one shouldn't force rotating the other.
# Generate with:
#   python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# then put it in .env as KYC_FIELD_ENCRYPTION_KEY. Never commit the real value.
KYC_FIELD_ENCRYPTION_KEY = os.environ.get("KYC_FIELD_ENCRYPTION_KEY")







DEBUG = os.environ.get("DEBUG", "True") == "True"

ALLOWED_HOSTS = [
    host.strip()
    for host in os.environ.get(
        "ALLOWED_HOSTS", "localhost,127.0.0.1"
    ).split(",")
    if host.strip()
]
AUTH_USER_MODEL = "accounts.User"

# Application definition

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.sites",
    'allauth',
    'allauth.account',
    'allauth.socialaccount',
    'allauth.socialaccount.providers.google',
    "apps.apps.MainConfig",
    "apps.accounts.apps.AccountsConfig",
    "apps.catalog.apps.CatalogConfig",
    "apps.cart.apps.CartConfig",
    "apps.orders.apps.OrdersConfig",
    "apps.payments.apps.PaymentsConfig",
    "apps.delivery.apps.DeliveryConfig",
    "apps.sellers.apps.SellersConfig",
    "apps.affiliates.apps.AffiliatesConfig",
    "apps.riders.apps.RidersConfig",
    "apps.notifications.apps.NotificationsConfig",
    "apps.ledger.apps.LedgerConfig",
    "apps.kyc.apps.KycConfig",
    "apps.logistics.apps.LogisticsConfig",
]

# Required by django-allauth SocialApp.sites.
# The Site with this ID is used by the allauth Sites framework.
SITE_ID = 1

# NOTE: these three are for the separate staff/admin login flow (whatever
# owns the 'custom_login' / 'admin_dashboard' url names) and are left as
# they were - the customer-facing accounts app below has its own login/
# signup/Google views and does not use these.
LOGIN_URL = "custom_login"
LOGIN_REDIRECT_URL = "admin_dashboard"
LOGOUT_REDIRECT_URL = "custom_login"

# Where the *customer* signup/login/Google flow sends people, instead of
# 'home' or a base page - referenced by apps/accounts/views.py and
# apps/accounts/adapters.py. Change this one value if your products-list
# url name isn't actually "products_list".
LOGIN_REDIRECT_URL = "catalog:product_list"

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "apps.affiliates.middleware.AffiliateTrackingMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    'allauth.account.middleware.AccountMiddleware',
]
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'allauth.account.auth_backends.AuthenticationBackend',
]

# Makes a returning user's "Continue with Google" work even when they
# originally signed up with username/password on the same email, instead
# of allauth's default "email already registered" error - see
# apps/accounts/adapters.py.
ACCOUNT_ADAPTER = 'apps.accounts.adapters.AccountAdapter'
SOCIALACCOUNT_ADAPTER = 'apps.accounts.adapters.SocialAccountAdapter'
SOCIALACCOUNT_AUTO_SIGNUP = True          # skip allauth's own "pick a username" page
SOCIALACCOUNT_EMAIL_VERIFICATION = 'none'  # Google already verified it
SOCIALACCOUNT_QUERY_EMAIL = True




ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "apps.cart.context_processors.cart_context",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"


# Database
# https://docs.djangoproject.com/en/6.0/ref/settings/#databases

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.environ.get("DB_NAME", "ecommerce_db"),
        "USER": os.environ.get("DB_USER", "database_admin"),
        "PASSWORD": os.environ.get("DB_PASSWORD"),
        "HOST": os.environ.get("DB_HOST", "localhost"),
        "PORT": os.environ.get("DB_PORT", "5432"),
    }
}






GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET")

SOCIALACCOUNT_PROVIDERS = {
    "google": {
        "APP": {
            "client_id": GOOGLE_CLIENT_ID,
            "secret": GOOGLE_CLIENT_SECRET,
            "key": "",
        },
        "SCOPE": [
            "profile",
            "email",
        ],
        "AUTH_PARAMS": {
            "access_type": "online",
        },
    }
}




# Password validation
# https://docs.djangoproject.com/en/6.0/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]


# Internationalization
# https://docs.djangoproject.com/en/6.0/topics/i18n/

LANGUAGE_CODE = "en-us"

TIME_ZONE = "UTC"

USE_I18N = True

USE_TZ = True


# Email
# In development, print emails to the console unless SMTP creds are set.

if os.environ.get("EMAIL_HOST_PASSWORD"):
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
    EMAIL_HOST = os.environ.get("EMAIL_HOST", "smtp.gmail.com")
    EMAIL_PORT = int(os.environ.get("EMAIL_PORT", "587"))
    EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", "True") == "True"
    EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER")
    EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD")
else:
    EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
    EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", "")

DEFAULT_FROM_EMAIL = EMAIL_HOST_USER


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/6.0/howto/static-files/

STATIC_URL = "/static/"

STATICFILES_DIRS = [BASE_DIR / "static"]

STATIC_ROOT = BASE_DIR / "staticfiles"

# Media files (user uploads)
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# Third-party services

STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY")
STRIPE_PUBLIC_KEY = os.environ.get("STRIPE_PUBLIC_KEY")

PAYSTACK_SECRET_KEY = os.environ.get("PAYSTACK_SECRET_KEY")
PAYSTACK_PUBLIC_KEY = os.environ.get("PAYSTACK_PUBLIC_KEY")
PAYSTACK_WEBHOOK_URL = os.environ.get(
    "PAYSTACK_WEBHOOK_URL",
    "https://toptech.pythonanywhere.com/webhook/paystack/",
)



# Phase 6 - referral tracking. How long a ?ref=<code> click stays
# attributed to a visitor (spec section 12: "configurable through
# settings rather than hard-coded throughout the application").
AFFILIATE_ATTRIBUTION_WINDOW_DAYS = int(
    os.environ.get("AFFILIATE_ATTRIBUTION_WINDOW_DAYS", "30")
)

# Phase 9 - seller/affiliate payouts (spec sections 19/20). Configurable
# per spec's own pattern above rather than hard-coded in services.py.
MINIMUM_SELLER_WITHDRAWAL = os.environ.get("MINIMUM_SELLER_WITHDRAWAL", "1000")
MINIMUM_AFFILIATE_WITHDRAWAL = os.environ.get("MINIMUM_AFFILIATE_WITHDRAWAL", "1000")