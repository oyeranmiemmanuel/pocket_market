from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase

from apps.catalog.models import Product
from apps.orders.models import Order, OrderItem
from apps.sellers.models import SellerProfile, SellerStatus

from .models import AffiliateClick, AffiliateCommission, AffiliateProfile, AffiliateStatus, CommissionStatus
from .services import (
    calculate_order_item_allocation,
    record_conversion_for_order,
    resolve_affiliate_commission_rate,
    reverse_commission,
)

User = get_user_model()


class CommissionCalculationTests(TestCase):
    """
    Phase 7 - spec section 48's worked example, end to end:

        Product price = 50,000
        Platform commission = 10%
        Affiliate commission = 5%

        Expected: platform = 5,000, affiliate = 2,500, seller = 42,500

    then a refund/reversal, which must cancel the affiliate commission
    without deleting the original record.
    """

    def setUp(self):
        self.customer = User.objects.create_user(
            username="buyer", email="buyer@example.com", password="pass12345",
        )

        seller_user = User.objects.create_user(
            username="seller", email="seller@example.com", password="pass12345",
        )
        self.seller = SellerProfile.objects.create(
            user=seller_user,
            store_name="Seller Store",
            store_slug="seller-store",
            phone="08000000001",
            business_email="seller@example.com",
            status=SellerStatus.APPROVED,
            # No override -> platform default (10%, per core.constants).
        )

        affiliate_user = User.objects.create_user(
            username="affiliate", email="affiliate@example.com", password="pass12345",
        )
        self.affiliate = AffiliateProfile.objects.create(
            user=affiliate_user,
            affiliate_code="AFF-TEST0001",
            status=AffiliateStatus.ACTIVE,
            # No override -> platform default (5%, per core.constants).
        )

        self.product = Product.objects.create(
            seller=self.seller, name="Nike Shoes", price=Decimal("50000.00"), stock=10,
        )

        self.order = Order.objects.create(
            user=self.customer,
            reference="ORD-TEST0001",
            email="buyer@example.com",
            full_name="Buyer One",
            phone="08011112222",
            subtotal=Decimal("50000.00"),
            shipping_fee=Decimal("0.00"),
            total=Decimal("50000.00"),
            affiliate=self.affiliate,
            affiliate_code=self.affiliate.affiliate_code,
        )
        self.order_item = OrderItem.objects.create(
            order=self.order,
            product=self.product,
            product_name=self.product.name,
            unit_price=self.product.price,
            quantity=1,
            seller=self.seller,
            platform_commission_rate=Decimal("10"),
        )

    def test_commission_rate_hierarchy_falls_through_to_platform_default(self):
        rate = resolve_affiliate_commission_rate(product=self.product, affiliate=self.affiliate)
        self.assertEqual(rate, Decimal("5"))

    def test_commission_rate_hierarchy_prefers_product_override(self):
        self.product.affiliate_commission_rate = Decimal("10.00")
        self.product.save(update_fields=["affiliate_commission_rate"])

        rate = resolve_affiliate_commission_rate(product=self.product, affiliate=self.affiliate)
        self.assertEqual(rate, Decimal("10.00"))

    def test_commission_rate_hierarchy_prefers_affiliate_specific_rate_over_everything(self):
        self.product.affiliate_commission_rate = Decimal("10.00")
        self.product.save(update_fields=["affiliate_commission_rate"])
        self.affiliate.commission_rate = Decimal("20.00")
        self.affiliate.save(update_fields=["commission_rate"])

        rate = resolve_affiliate_commission_rate(product=self.product, affiliate=self.affiliate)
        self.assertEqual(rate, Decimal("20.00"))

    def test_order_item_allocation_matches_spec_worked_example(self):
        allocation = calculate_order_item_allocation(order_item=self.order_item, affiliate=self.affiliate)

        self.assertEqual(allocation["platform_amount"], Decimal("5000.00"))
        self.assertEqual(allocation["affiliate_amount"], Decimal("2500.00"))
        self.assertEqual(allocation["seller_amount"], Decimal("42500.00"))
        # The three splits must always fully account for the gross amount.
        self.assertEqual(
            allocation["platform_amount"] + allocation["affiliate_amount"] + allocation["seller_amount"],
            allocation["gross"],
        )

    def test_record_conversion_creates_pending_commission(self):
        created = record_conversion_for_order(self.order)

        self.assertEqual(len(created), 1)
        commission = AffiliateCommission.objects.get(order_item=self.order_item)
        self.assertEqual(commission.affiliate, self.affiliate)
        self.assertEqual(commission.commission_rate, Decimal("5"))
        self.assertEqual(commission.commission_amount, Decimal("2500.00"))
        self.assertEqual(commission.status, CommissionStatus.PENDING)

    def test_record_conversion_is_idempotent(self):
        """Calling this twice (e.g. callback + webhook both firing) must never create a second commission."""
        record_conversion_for_order(self.order)
        record_conversion_for_order(self.order)

        self.assertEqual(AffiliateCommission.objects.filter(order_item=self.order_item).count(), 1)

    def test_no_commission_without_an_attributed_affiliate(self):
        self.order.affiliate = None
        self.order.save(update_fields=["affiliate"])

        created = record_conversion_for_order(self.order)

        self.assertEqual(created, [])
        self.assertFalse(AffiliateCommission.objects.filter(order_item=self.order_item).exists())

    def test_suspended_affiliate_earns_nothing(self):
        self.affiliate.status = AffiliateStatus.SUSPENDED
        self.affiliate.save(update_fields=["status"])

        created = record_conversion_for_order(self.order)

        self.assertEqual(created, [])
        self.assertFalse(AffiliateCommission.objects.filter(order_item=self.order_item).exists())

    def test_self_referral_earns_nothing(self):
        """An affiliate must never earn a commission on their own purchase."""
        self.order.user = self.affiliate.user
        self.order.affiliate = self.affiliate
        self.order.save(update_fields=["user", "affiliate"])

        created = record_conversion_for_order(self.order)

        self.assertEqual(created, [])
        self.assertFalse(AffiliateCommission.objects.filter(order_item=self.order_item).exists())

    def test_refund_reverses_commission_without_deleting_the_original(self):
        record_conversion_for_order(self.order)
        commission = AffiliateCommission.objects.get(order_item=self.order_item, reversal_of__isnull=True)

        reversal = reverse_commission(commission=commission, reason="Order refunded.")
        commission.refresh_from_db()

        # Original preserved, just flipped to REVERSED - never deleted.
        self.assertEqual(commission.status, CommissionStatus.REVERSED)
        self.assertEqual(reversal.reversal_of, commission)
        self.assertEqual(reversal.commission_amount, -commission.commission_amount)

        # Reversed commissions must not count toward the affiliate's earnings anymore.
        self.affiliate.refresh_from_db()
        self.assertEqual(self.affiliate.total_earnings, Decimal("0.00"))

from django.core import signing
from django.urls import reverse

from apps.catalog.models import Product
from apps.core.constants import AFFILIATE_ATTRIBUTION_COOKIE_NAME
from apps.core.enums import PayoutStatus
from apps.core.exceptions import ValidationFailedError
from apps.orders.services.checkout import create_order_from_cart
from apps.cart.models import Cart, CartItem

from .services import (
    apply_for_affiliate,
    approve_affiliate,
    generate_affiliate_link,
    get_attributed_affiliate,
    reject_affiliate,
    request_affiliate_payout,
    suspend_affiliate,
)


class AffiliateRegistrationLifecycleTests(TestCase):
    """Spec section 47: affiliate registration, approval, rejection, suspension."""

    def setUp(self):
        self.user = User.objects.create_user(username="newaffiliate", email="newaffiliate@example.com", password="pass12345")

    def test_registration_creates_pending_application_with_generated_code(self):
        profile = apply_for_affiliate(user=self.user)
        self.assertEqual(profile.status, AffiliateStatus.PENDING)
        self.assertTrue(profile.affiliate_code.startswith("AFF-"))

    def test_cannot_apply_twice(self):
        apply_for_affiliate(user=self.user)
        with self.assertRaises(ValidationFailedError):
            apply_for_affiliate(user=self.user)

    def test_approval_moves_pending_to_active(self):
        admin_user = User.objects.create_user(username="admin4", email="admin4@example.com", password="pass12345")
        profile = apply_for_affiliate(user=self.user)
        approve_affiliate(profile=profile, reviewed_by=admin_user)
        profile.refresh_from_db()
        self.assertEqual(profile.status, AffiliateStatus.ACTIVE)

    def test_rejection_records_reason(self):
        admin_user = User.objects.create_user(username="admin5", email="admin5@example.com", password="pass12345")
        profile = apply_for_affiliate(user=self.user)
        reject_affiliate(profile=profile, reviewed_by=admin_user, reason="Not eligible.")
        profile.refresh_from_db()
        self.assertEqual(profile.status, AffiliateStatus.REJECTED)

    def test_suspension_of_a_previously_active_affiliate(self):
        admin_user = User.objects.create_user(username="admin6", email="admin6@example.com", password="pass12345")
        profile = apply_for_affiliate(user=self.user)
        approve_affiliate(profile=profile, reviewed_by=admin_user)
        suspend_affiliate(profile=profile, reviewed_by=admin_user, reason="Fraud suspected.")
        profile.refresh_from_db()
        self.assertEqual(profile.status, AffiliateStatus.SUSPENDED)


class AffiliateLinkGenerationTests(TestCase):
    """Spec section 47: affiliate link generation."""

    def setUp(self):
        seller_user = User.objects.create_user(username="linkseller", email="linkseller@example.com", password="pass12345")
        self.seller = SellerProfile.objects.create(
            user=seller_user, store_name="Link Seller Store", store_slug="link-seller-store",
            phone="08000000003", business_email="linkseller@example.com", status=SellerStatus.APPROVED,
        )
        self.product = Product.objects.create(seller=self.seller, name="Linked Product", price=Decimal("10000.00"), stock=5)
        affiliate_user = User.objects.create_user(username="linkaffiliate", email="linkaffiliate@example.com", password="pass12345")
        self.affiliate = AffiliateProfile.objects.create(
            user=affiliate_user, affiliate_code="AFF-LINKTEST", status=AffiliateStatus.ACTIVE,
        )

    def test_generate_link_creates_active_link(self):
        link = generate_affiliate_link(affiliate=self.affiliate, product=self.product)
        self.assertTrue(link.is_active)
        self.assertEqual(link.referral_code, self.affiliate.affiliate_code)

    def test_generating_twice_reuses_the_same_link(self):
        link1 = generate_affiliate_link(affiliate=self.affiliate, product=self.product)
        link2 = generate_affiliate_link(affiliate=self.affiliate, product=self.product)
        self.assertEqual(link1.pk, link2.pk)


class AffiliateTrackingAndAttributionTests(TestCase):
    """
    Spec section 47: affiliate tracking, affiliate cookie/session, guest
    affiliate tracking, affiliate attribution. Exercises the real
    AffiliateTrackingMiddleware via the Django test client, not just the
    service function directly.
    """

    def setUp(self):
        seller_user = User.objects.create_user(username="trackseller", email="trackseller@example.com", password="pass12345")
        self.seller = SellerProfile.objects.create(
            user=seller_user, store_name="Track Seller Store", store_slug="track-seller-store",
            phone="08000000004", business_email="trackseller@example.com", status=SellerStatus.APPROVED,
        )
        self.product = Product.objects.create(
            seller=self.seller, name="Tracked Product", slug="tracked-product",
            price=Decimal("10000.00"), stock=5, is_active=True,
        )
        affiliate_user = User.objects.create_user(username="trackaffiliate", email="trackaffiliate@example.com", password="pass12345")
        self.affiliate = AffiliateProfile.objects.create(
            user=affiliate_user, affiliate_code="AFF-TRACKTEST", status=AffiliateStatus.ACTIVE,
        )

    def test_guest_visiting_a_ref_link_gets_tracked_and_cookied(self):
        """A completely anonymous, not-logged-in visitor - no session/account exists beforehand."""
        url = reverse("catalog:product_detail", args=[self.product.slug]) + f"?ref={self.affiliate.affiliate_code}"
        response = self.client.get(url)

        self.assertEqual(response.status_code, 200)
        self.assertTrue(AffiliateClick.objects.filter(affiliate=self.affiliate, product=self.product).exists())
        self.assertIn(AFFILIATE_ATTRIBUTION_COOKIE_NAME, response.cookies)

        cookie_value = response.cookies[AFFILIATE_ATTRIBUTION_COOKIE_NAME].value
        self.assertEqual(signing.loads(cookie_value), self.affiliate.affiliate_code)

    def test_repeat_visit_within_dedup_window_does_not_double_log_a_click(self):
        url = reverse("catalog:product_detail", args=[self.product.slug]) + f"?ref={self.affiliate.affiliate_code}"
        self.client.get(url)
        self.client.get(url)
        self.assertEqual(AffiliateClick.objects.filter(affiliate=self.affiliate, product=self.product).count(), 1)

    def test_invalid_ref_code_never_breaks_the_page(self):
        url = reverse("catalog:product_detail", args=[self.product.slug]) + "?ref=NOT-A-REAL-CODE"
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertNotIn(AFFILIATE_ATTRIBUTION_COOKIE_NAME, response.cookies)

    def test_affiliate_cannot_generate_a_click_on_their_own_link(self):
        self.client.login(username="trackaffiliate", password="pass12345")
        url = reverse("catalog:product_detail", args=[self.product.slug]) + f"?ref={self.affiliate.affiliate_code}"
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(AffiliateClick.objects.filter(affiliate=self.affiliate).exists())
        self.assertNotIn(AFFILIATE_ATTRIBUTION_COOKIE_NAME, response.cookies)

    def test_get_attributed_affiliate_reads_a_valid_cookie(self):
        factory_request = type("R", (), {})()
        factory_request.COOKIES = {AFFILIATE_ATTRIBUTION_COOKIE_NAME: signing.dumps(self.affiliate.affiliate_code)}
        resolved = get_attributed_affiliate(factory_request)
        self.assertEqual(resolved, self.affiliate)

    def test_get_attributed_affiliate_rejects_a_tampered_cookie(self):
        factory_request = type("R", (), {})()
        factory_request.COOKIES = {AFFILIATE_ATTRIBUTION_COOKIE_NAME: "not-a-real-signed-value"}
        self.assertIsNone(get_attributed_affiliate(factory_request))

    def test_guest_checkout_carries_the_attributed_affiliate_onto_the_order(self):
        """Affiliate attribution, end to end: a guest cart checked out with a resolved affiliate."""
        cart = Cart.objects.create(session_key="guest-session-key-1")
        CartItem.objects.create(cart=cart, product=self.product, quantity=1)

        order = create_order_from_cart(
            user=None, cart=cart, email="guest@example.com", full_name="Guest Buyer",
            phone="08099990000", delivery_method="shipping",
            shipping_data={"address_line1": "1 Guest St", "city": "Lagos", "state": "Lagos", "postal_code": "100001", "country": "Nigeria"},
            affiliate=self.affiliate,
        )
        self.assertEqual(order.affiliate, self.affiliate)
        self.assertEqual(order.affiliate_code, self.affiliate.affiliate_code)
        self.assertIsNone(order.user)


class AffiliatePayoutTests(TestCase):
    """Spec section 47: payout creation, payout validation (affiliate side)."""

    def setUp(self):
        user = User.objects.create_user(username="payoutaffiliate", email="payoutaffiliate@example.com", password="pass12345")
        self.affiliate = AffiliateProfile.objects.create(
            user=user, affiliate_code="AFF-PAYOUTTEST", status=AffiliateStatus.ACTIVE,
            bank_name="Test Bank", bank_code="058",
            bank_account_number="0123456789", bank_account_name="Payout Affiliate",
        )

    def _make_available_commission(self, amount):
        seller_user = User.objects.create_user(
            username=f"pseller{AffiliateCommission.objects.count()}",
            email=f"pseller{AffiliateCommission.objects.count()}@example.com", password="pass12345",
        )
        seller = SellerProfile.objects.create(
            user=seller_user, store_name="P Seller", store_slug=f"p-seller-{AffiliateCommission.objects.count()}",
            phone="08000000005", business_email=seller_user.email, status=SellerStatus.APPROVED,
        )
        buyer = User.objects.create_user(
            username=f"pbuyer{AffiliateCommission.objects.count()}",
            email=f"pbuyer{AffiliateCommission.objects.count()}@example.com", password="pass12345",
        )
        order = Order.objects.create(
            user=buyer, reference=f"ORD-P-{AffiliateCommission.objects.count()}", status="paid",
            email=buyer.email, full_name="Buyer", phone="08000000000", subtotal=amount, total=amount,
            affiliate=self.affiliate, affiliate_code=self.affiliate.affiliate_code,
        )
        item = OrderItem.objects.create(order=order, product_name="Item", unit_price=amount, quantity=1, seller=seller)
        return AffiliateCommission.objects.create(
            affiliate=self.affiliate, order=order, order_item=item,
            commission_rate=Decimal("5"), commission_amount=amount, status=CommissionStatus.AVAILABLE,
        )

    def test_cannot_request_below_minimum_withdrawal(self):
        self._make_available_commission(Decimal("10000.00"))
        with self.assertRaises(ValidationFailedError):
            request_affiliate_payout(affiliate=self.affiliate, amount=Decimal("100.00"))

    def test_cannot_request_more_than_available_balance(self):
        self._make_available_commission(Decimal("1000.00"))
        with self.assertRaises(ValidationFailedError):
            request_affiliate_payout(affiliate=self.affiliate, amount=Decimal("50000.00"))

    def test_successful_payout_request(self):
        self._make_available_commission(Decimal("10000.00"))
        payout = request_affiliate_payout(affiliate=self.affiliate, amount=Decimal("6000.00"))
        self.assertEqual(payout.status, PayoutStatus.PENDING)
        self.assertGreaterEqual(payout.amount, Decimal("6000.00"))