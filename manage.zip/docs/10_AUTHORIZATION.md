# Authorization

Role-based permissions.