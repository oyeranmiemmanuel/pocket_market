# Authorization

Role-based permissions.