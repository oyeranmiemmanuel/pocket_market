from django.contrib import admin

from .models import Order, OrderItem, ShippingAddress


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ["product", "product_name", "unit_price", "quantity"]


class ShippingAddressInline(admin.StackedInline):
    model = ShippingAddress
    extra = 0


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ["reference", "full_name", "email", "status", "total", "created_at"]
    list_filter = ["status"]
    search_fields = ["reference", "email", "full_name"]
    inlines = [OrderItemInline, ShippingAddressInline]


@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    """
    Phase 12 - spec section 32 lists Order Items as their own manageable
    entity, separate from the OrderItemInline above (which stays, for
    quick viewing from inside an Order). Line items are created only at
    checkout (apps.orders.services), so this is read-only except for
    fulfillment_status - the one field a seller/admin legitimately needs
    to change after the fact.
    """

    list_display = [
        "order", "product_name", "seller", "quantity",
        "unit_price", "fulfillment_status", "created_at",
    ]
    list_filter = ["fulfillment_status", "seller", "created_at"]
    search_fields = ["order__reference", "product_name", "seller__store_name"]
    readonly_fields = ["order", "product", "seller", "product_name", "unit_price", "quantity"]